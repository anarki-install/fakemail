# fake-email-generator
Fake Emails Generator

# Requirements
Faker - pip install Faker

# Note
This is not the best version for this thing but this works perfectly. Made this in my spare time. Star if you like this.
